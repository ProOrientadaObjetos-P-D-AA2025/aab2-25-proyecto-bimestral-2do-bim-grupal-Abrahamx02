/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.sql.*;

/**
 *
 * @author abrah
 */
public class DatabaseManager {
    private static final String DB_NAME = "movutpl.db";
    private static final String DB_URL = "jdbc:sqlite:" + DB_NAME;
    
    // Método para obtener conexión
    public static Connection getConnection() throws SQLException {
    try {
        Class.forName("org.sqlite.JDBC"); // Carga manual del driver
    } catch (ClassNotFoundException e) {
        System.out.println("Error: Driver SQLite no encontrado");
        e.printStackTrace();
    }
    return DriverManager.getConnection(DB_URL);
}

    
    // Método para crear las tablas si no existen
    public static void crearTablas() {
        String sqlClientes = """
            CREATE TABLE IF NOT EXISTS clientes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombres TEXT NOT NULL,
                pasaporte_cedula TEXT UNIQUE NOT NULL,
                ciudad TEXT NOT NULL,
                marca_celular TEXT NOT NULL,
                modelo_celular TEXT NOT NULL,
                numero_celular TEXT UNIQUE NOT NULL,
                email TEXT,
                carrera TEXT
            )
        """;
        
        String sqlPlanes = """
            CREATE TABLE IF NOT EXISTS planes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tipo_plan TEXT NOT NULL,
                nombre TEXT NOT NULL,
                descripcion TEXT,
                activo INTEGER DEFAULT 1,
                minutos INTEGER,
                costo_minutos REAL,
                minutos_nacionales INTEGER,
                costo_minuto_nacional REAL,
                minutos_internacionales INTEGER,
                costo_minuto_internacional REAL,
                megas_gigas REAL,
                costo_por_giga REAL,
                tarifa_base REAL,
                porcentaje_descuento REAL
            )
        """;
        
        String sqlClientePlanes = """
            CREATE TABLE IF NOT EXISTS cliente_planes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                cliente_id INTEGER,
                plan_id INTEGER,
                activo INTEGER DEFAULT 1,
                FOREIGN KEY (cliente_id) REFERENCES clientes(id),
                FOREIGN KEY (plan_id) REFERENCES planes(id)
            )
        """;
        
        String sqlFacturas = """
            CREATE TABLE IF NOT EXISTS facturas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                cliente_id INTEGER,
                periodo_facturacion TEXT,
                subtotal REAL,
                descuentos REAL,
                total REAL,
                estado TEXT DEFAULT 'PENDIENTE',
                FOREIGN KEY (cliente_id) REFERENCES clientes(id)
            )
        """;
        
        try (Connection conn = getConnection()) {
            Statement stmt = conn.createStatement();
            stmt.execute(sqlClientes);
            stmt.execute(sqlPlanes);
            stmt.execute(sqlClientePlanes);
            stmt.execute(sqlFacturas);
            System.out.println("Tablas creadas exitosamente");
        } catch (SQLException e) {
            System.out.println("Error al crear tablas: " + e.getMessage());
        }
    }
}

