/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import java.util.List;
import java.util.Scanner;
import model.*;
import controller.*;

/**
 *
 * @author abrah
 */
public class MenuInteractivo {
    private static Scanner scanner = new Scanner(System.in);
    private static ClienteController clienteController = new ClienteController();
    private static PlanController planController = new PlanController();
    private static FacturaController facturaController = new FacturaController();
    
    public static void main(String[] args) {
        // Inicializar base de datos
        DatabaseManager.crearTablas();
        
        // Crear algunos planes iniciales
        inicializarPlanesBase();
        
        System.out.println("=== BIENVENIDO AL SISTEMA MOV-UTPL ===");
        
        boolean continuar = true;
        while (continuar) {
            mostrarMenuPrincipal();
            int opcion = leerOpcion();
            
            switch (opcion) {
                case 1:
                    menuClientes();
                    break;
                case 2:
                    menuPlanes();
                    break;
                case 3:
                    menuFacturacion();
                    break;
                case 4:
                    menuReportes();
                    break;
                case 5:
                    TestSistema.ejecutarPruebas();
                    break;
                case 0:
                    continuar = false;
                    System.out.println("¡Gracias por usar el Sistema Mov-UTPL!");
                    break;
                default:
                    System.out.println("Opción inválida. Intente nuevamente.");
            }
        }
        
        scanner.close();
    }
    
    private static void mostrarMenuPrincipal() {
        System.out.println("\n=== MENÚ PRINCIPAL ===");
        System.out.println("1. Gestión de Clientes");
        System.out.println("2. Gestión de Planes");
        System.out.println("3. Facturación");
        System.out.println("4. Reportes");
        System.out.println("5. Ejecutar Pruebas del Sistema");
        System.out.println("0. Salir");
        System.out.print("Seleccione una opción: ");
    }
    
    private static void menuClientes() {
        boolean volver = false;
        while (!volver) {
            System.out.println("\n=== GESTIÓN DE CLIENTES ===");
            System.out.println("1. Crear Cliente");
            System.out.println("2. Buscar Cliente");
            System.out.println("3. Listar Todos los Clientes");
            System.out.println("4. Asignar Plan a Cliente");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");
            
            int opcion = leerOpcion();
            
            switch (opcion) {
                case 1:
                    crearCliente();
                    break;
                case 2:
                    buscarCliente();
                    break;
                case 3:
                    listarClientes();
                    break;
                case 4:
                    asignarPlanACliente();
                    break;
                case 0:
                    volver = true;
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        }
    }
    
    private static void menuPlanes() {
        boolean volver = false;
        while (!volver) {
            System.out.println("\n=== GESTIÓN DE PLANES ===");
            System.out.println("1. Crear Plan Económico");
            System.out.println("2. Crear Plan Solo Minutos");
            System.out.println("3. Crear Plan Solo Megas");
            System.out.println("4. Crear Plan Minutos+Megas");
            System.out.println("5. Listar Todos los Planes");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");
            
            int opcion = leerOpcion();
            
            switch (opcion) {
                case 1:
                    crearPlanEconomico();
                    break;
                case 2:
                    crearPlanMinutos();
                    break;
                case 3:
                    crearPlanMegas();
                    break;
                case 4:
                    crearPlanMinutosMegas();
                    break;
                case 5:
                    planController.mostrarPlanesDisponibles();
                    break;
                case 0:
                    volver = true;
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        }
    }
    
    private static void menuFacturacion() {
        System.out.println("\n=== FACTURACIÓN ===");
        System.out.print("Ingrese el ID del cliente: ");
        int clienteId = leerOpcion();
        
        System.out.print("Ingrese el período (ej: Enero 2025): ");
        scanner.nextLine(); // Limpiar buffer
        String periodo = scanner.nextLine();
        
        String factura = facturaController.generarFacturaCliente(clienteId, periodo);
        System.out.println(factura);
    }
    
    private static void menuReportes() {
        System.out.println("\n=== REPORTES ===");
        System.out.println("1. Reporte de Clientes");
        System.out.println("2. Reporte de Planes");
        System.out.println("3. Ingresos Totales");
        System.out.print("Seleccione una opción: ");
        
        int opcion = leerOpcion();
        
        switch (opcion) {
            case 1:
                List<Cliente> clientes = clienteController.obtenerTodosLosClientes();
                System.out.println(ReporteUtils.generarReporteClientes(clientes));
                break;
            case 2:
                List<PlanMovil> planes = planController.obtenerTodosLosPlanes();
                System.out.println(ReporteUtils.generarReportePlanes(planes));
                break;
            case 3:
                double ingresos = facturaController.calcularTotalIngresosMensuales();
                System.out.println("Ingresos mensuales totales: $" + String.format("%.2f", ingresos));
                break;
            default:
                System.out.println("Opción inválida.");
        }
    }
    
    // Métodos auxiliares para operaciones específicas
    private static void crearCliente() {
        scanner.nextLine(); // Limpiar buffer
        
        System.out.print("Nombres: ");
        String nombres = scanner.nextLine();
        
        System.out.print("Cédula/Pasaporte: ");
        String cedula = scanner.nextLine();
        
        System.out.print("Ciudad: ");
        String ciudad = scanner.nextLine();
        
        System.out.print("Marca del celular: ");
        String marca = scanner.nextLine();
        
        System.out.print("Modelo del celular: ");
        String modelo = scanner.nextLine();
        
        System.out.print("Número de celular: ");
        String numero = scanner.nextLine();
        
        System.out.print("Email: ");
        String email = scanner.nextLine();
        
        System.out.print("Carrera: ");
        String carrera = scanner.nextLine();
        
        boolean resultado = clienteController.crearCliente(nombres, cedula, ciudad, marca, modelo, numero, email, carrera);
        
        if (resultado) {
            System.out.println("✓ Cliente creado exitosamente");
        } else {
            System.out.println("✗ Error al crear cliente");
        }
    }
    
    private static void buscarCliente() {
        System.out.print("Ingrese el ID del cliente: ");
        int id = leerOpcion();
        clienteController.mostrarInformacionCliente(id);
    }
    
    private static void listarClientes() {
        List<Cliente> clientes = clienteController.obtenerTodosLosClientes();
        if (clientes.isEmpty()) {
            System.out.println("No hay clientes registrados");
        } else {
            System.out.println("=== LISTA DE CLIENTES ===");
            for (Cliente cliente : clientes) {
                System.out.println("ID: " + cliente.getId() + " - " + cliente.getNombres() + 
                                 " (Planes: " + cliente.getPlanes().size() + "/2)");
            }
        }
    }
    
    private static void asignarPlanACliente() {
        System.out.print("ID del cliente: ");
        int clienteId = leerOpcion();
        
        planController.mostrarPlanesDisponibles();
        
        System.out.print("ID del plan a asignar: ");
        int planId = leerOpcion();
        
        boolean resultado = planController.asignarPlanACliente(clienteId, planId);
        
        if (resultado) {
            System.out.println("✓ Plan asignado exitosamente");
        } else {
            System.out.println("✗ Error al asignar plan (cliente puede tener máximo 2 planes)");
        }
    }
    
    private static void crearPlanEconomico() {
        scanner.nextLine(); // Limpiar buffer
        
        System.out.print("Nombre del plan: ");
        String nombre = scanner.nextLine();
        
        System.out.print("Descripción: ");
        String descripcion = scanner.nextLine();
        
        System.out.print("Minutos incluidos: ");
        int minutos = scanner.nextInt();
        
        System.out.print("Costo por minuto: ");
        double costoMinutos = scanner.nextDouble();
        
        System.out.print("Gigas incluidos: ");
        double gigas = scanner.nextDouble();
        
        System.out.print("Costo por giga: ");
        double costoGiga = scanner.nextDouble();
        
        System.out.print("Porcentaje de descuento: ");
        double descuento = scanner.nextDouble();
        
        boolean resultado = planController.crearPlanEconomico(nombre, descripcion, minutos, costoMinutos, gigas, costoGiga, descuento);
        
        if (resultado) {
            System.out.println("✓ Plan económico creado exitosamente");
        } else {
            System.out.println("✗ Error al crear plan");
        }
    }
    
    private static void crearPlanMinutos() {
        scanner.nextLine(); // Limpiar buffer
        
        System.out.print("Nombre del plan: ");
        String nombre = scanner.nextLine();
        
        System.out.print("Descripción: ");
        String descripcion = scanner.nextLine();
        
        System.out.print("Minutos nacionales: ");
        int minutosNac = scanner.nextInt();
        
        System.out.print("Costo minuto nacional: ");
        double costoNac = scanner.nextDouble();
        
        System.out.print("Minutos internacionales: ");
        int minutosInt = scanner.nextInt();
        
        System.out.print("Costo minuto internacional: ");
        double costoInt = scanner.nextDouble();
        
        boolean resultado = planController.crearPlanMinutos(nombre, descripcion, minutosNac, costoNac, minutosInt, costoInt);
        
        if (resultado) {
            System.out.println("✓ Plan de minutos creado exitosamente");
        } else {
            System.out.println("✗ Error al crear plan");
        }
    }
    
    private static void crearPlanMegas() {
        scanner.nextLine(); // Limpiar buffer
        
        System.out.print("Nombre del plan: ");
        String nombre = scanner.nextLine();
        
        System.out.print("Descripción: ");
        String descripcion = scanner.nextLine();
        
        System.out.print("Gigas incluidos: ");
        double gigas = scanner.nextDouble();
        
        System.out.print("Costo por giga: ");
        double costoGiga = scanner.nextDouble();
        
        System.out.print("Tarifa base: ");
        double tarifaBase = scanner.nextDouble();
        
        boolean resultado = planController.crearPlanMegas(nombre, descripcion, gigas, costoGiga, tarifaBase);
        
        if (resultado) {
            System.out.println("✓ Plan de megas creado exitosamente");
        } else {
            System.out.println("✗ Error al crear plan");
        }
    }
    
    private static void crearPlanMinutosMegas() {
        scanner.nextLine(); // Limpiar buffer
        
        System.out.print("Nombre del plan: ");
        String nombre = scanner.nextLine();
        
        System.out.print("Descripción: ");
        String descripcion = scanner.nextLine();
        
        System.out.print("Minutos incluidos: ");
        int minutos = scanner.nextInt();
        
        System.out.print("Costo por minuto: ");
        double costoMinutos = scanner.nextDouble();
        
        System.out.print("Gigas incluidos: ");
        double gigas = scanner.nextDouble();
        
        System.out.print("Costo por giga: ");
        double costoGiga = scanner.nextDouble();
        
        boolean resultado = planController.crearPlanMinutosMegas(nombre, descripcion, minutos, costoMinutos, gigas, costoGiga);
        
        if (resultado) {
            System.out.println("✓ Plan minutos+megas creado exitosamente");
        } else {
            System.out.println("✗ Error al crear plan");
        }
    }
    
    private static int leerOpcion() {
        try {
            return scanner.nextInt();
        } catch (Exception e) {
            scanner.nextLine(); // Limpiar buffer
            return -1;
        }
    }
    
    private static void inicializarPlanesBase() {
        planController.crearPlanEconomico("Plan Estudiante Básico", "Plan económico para estudiantes", 
                                         300, 0.05, 3.0, 2.0, 15.0);
        
        planController.crearPlanMinutos("Plan Llamadas Ilimitadas", "Para quienes hablan mucho", 
                                      2000, 0.02, 100, 0.12);
        
        planController.crearPlanMegas("Plan Internet Pro", "Navegación sin límites", 
                                    20.0, 1.0, 8.0);
        
        planController.crearPlanMinutosMegas("Plan Todo Incluido", "La mejor opción completa", 
                                           1000, 0.03, 12.0, 1.5);
    }
}
