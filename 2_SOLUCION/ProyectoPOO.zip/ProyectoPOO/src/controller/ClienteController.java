/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import java.util.List;
import model.*;
/**
 *
 * @author abrah
 */
public class ClienteController {
    private ClienteDAO clienteDAO;
    
    public ClienteController() {
        this.clienteDAO = new ClienteDAO();
    }
    
    // Crear nuevo cliente
    public boolean crearCliente(String nombres, String cedula, String ciudad, 
                              String marca, String modelo, String numero, 
                              String email, String carrera) {
        Cliente cliente = new Cliente(nombres, cedula, ciudad, marca, modelo, numero, email, carrera);
        return clienteDAO.insertarCliente(cliente);
    }
    
    // Obtener cliente por ID
    public Cliente obtenerCliente(int id) {
        return clienteDAO.buscarClientePorId(id);
    }
    
    // Obtener todos los clientes
    public List<Cliente> obtenerTodosLosClientes() {
        return clienteDAO.obtenerTodosLosClientes();
    }
    
    // Actualizar cliente
    public boolean actualizarCliente(Cliente cliente) {
        return clienteDAO.actualizarCliente(cliente);
    }
    
    // Eliminar cliente
    public boolean eliminarCliente(int id) {
        return clienteDAO.eliminarCliente(id);
    }
    
    // Mostrar información de un cliente
    public void mostrarInformacionCliente(int id) {
        Cliente cliente = obtenerCliente(id);
        if (cliente != null) {
            System.out.println(cliente.mostrarInformacion());
        } else {
            System.out.println("Cliente no encontrado");
        }
    }
}

