/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import java.util.List;
import model.*;
import controller.*;

public class Main {
    public static void main(String[] args) {
        // Inicializar base de datos
        DatabaseManager.crearTablas();
        
        // Crear controladores
        ClienteController clienteController = new ClienteController();
        PlanController planController = new PlanController();
        FacturaController facturaController = new FacturaController();
        
        System.out.println("=== SISTEMA MOV-UTPL INICIADO ===\n");
        
        // Ejemplo de uso completo del sistema
        System.out.println("=== CREANDO PLANES INICIALES ===");
        
        // Crear diferentes tipos de planes
        planController.crearPlanEconomico("Plan Estudiante", "Plan especial para estudiantes", 
                                         500, 0.05, 5.0, 2.0, 20.0);
        
        planController.crearPlanMinutos("Plan Llamadas", "Para quienes solo llaman", 
                                      1000, 0.03, 200, 0.15);
        
        planController.crearPlanMegas("Plan Internet", "Para navegación", 
                                    10.0, 1.5, 5.0);
        
        planController.crearPlanMinutosMegas("Plan Completo", "Lo mejor de ambos", 
                                           800, 0.04, 15.0, 1.2);
        
        System.out.println("Planes creados exitosamente\n");
        
        // Crear clientes de ejemplo
        System.out.println("=== CREANDO CLIENTES ===");
        
        clienteController.crearCliente("Juan Pérez", "1234567890", "Loja", 
                                     "Samsung", "Galaxy S21", "0987654321", 
                                     "juan.perez@utpl.edu.ec", "Telecomunicaciones");
        
        clienteController.crearCliente("María García", "0987654321", "Quito", 
                                     "iPhone", "14 Pro", "0912345678", 
                                     "maria.garcia@utpl.edu.ec", "Sistemas");
        
        System.out.println("Clientes creados exitosamente\n");
        
        // Asignar planes a clientes
        System.out.println("=== ASIGNANDO PLANES ===");
        planController.asignarPlanACliente(1, 1); // Cliente 1 -> Plan 1
        planController.asignarPlanACliente(1, 2); // Cliente 1 -> Plan 2
        planController.asignarPlanACliente(2, 3); // Cliente 2 -> Plan 3
        
        System.out.println("Planes asignados exitosamente\n");
        
        // Mostrar información de clientes
        System.out.println("=== INFORMACIÓN DE CLIENTES ===");
        clienteController.mostrarInformacionCliente(1);
        clienteController.mostrarInformacionCliente(2);
        
        // Mostrar planes disponibles
        System.out.println("=== PLANES DISPONIBLES ===");
        planController.mostrarPlanesDisponibles();
        
        // Generar facturas
        System.out.println("=== GENERANDO FACTURAS ===");
        String factura1 = facturaController.generarFacturaCliente(1, "Enero 2025");
        String factura2 = facturaController.generarFacturaCliente(2, "Enero 2025");
        
        System.out.println(factura1);
        System.out.println(factura2);
        
        // Mostrar ingresos totales
        double ingresosTotales = facturaController.calcularTotalIngresosMensuales();
        System.out.println("=== RESUMEN FINANCIERO ===");
        System.out.println("Ingresos mensuales totales: $" + String.format("%.2f", ingresosTotales));
        
        // Demostrar polimorfismo con diferentes tipos de planes
        System.out.println("\n=== DEMOSTRACIÓN DE POLIMORFISMO ===");
        List<PlanMovil> todosLosPlanes = planController.obtenerTodosLosPlanes();
        
        System.out.println("Calculando costos usando polimorfismo:");
        double costoTotalPlanes = 0;
        
        for (PlanMovil plan : todosLosPlanes) {
            // Aquí se demuestra el POLIMORFISMO - cada plan calcula su costo de forma diferente
            double costo = plan.calcularCosto();
            costoTotalPlanes += costo;
            
            System.out.println("- " + plan.getNombre() + " (" + plan.getTipoPlan() + "): $" + 
                             String.format("%.2f", costo));
        }
        
        System.out.println("Costo promedio de planes: $" + 
                         String.format("%.2f", costoTotalPlanes / todosLosPlanes.size()));
        
        System.out.println("\n=== SISTEMA FINALIZADO ===");
    }
}

