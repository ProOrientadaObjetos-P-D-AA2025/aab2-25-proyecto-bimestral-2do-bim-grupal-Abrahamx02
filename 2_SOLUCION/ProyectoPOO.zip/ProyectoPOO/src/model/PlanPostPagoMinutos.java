/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author abrah
 */
public class PlanPostPagoMinutos extends PlanMovil {

    private int minutosNacionales;
    private double costoMinutoNacional;
    private int minutosInternacionales;
    private double costoMinutoInternacional;

    // Constructor vacío
    public PlanPostPagoMinutos() {
        super();
    }

    // Constructor con parámetros
    public PlanPostPagoMinutos(String nombre, String descripcion, int minutosNacionales,
            double costoMinutoNacional, int minutosInternacionales,
            double costoMinutoInternacional) {
        super(nombre, descripcion);
        this.minutosNacionales = minutosNacionales;
        this.costoMinutoNacional = costoMinutoNacional;
        this.minutosInternacionales = minutosInternacionales;
        this.costoMinutoInternacional = costoMinutoInternacional;
    }

    // POLIMORFISMO - Implementación específica del cálculo de costo
    @Override
    public double calcularCosto() {
        double costoNacional = minutosNacionales * costoMinutoNacional;
        double costoInternacional = minutosInternacionales * costoMinutoInternacional;
        return costoNacional + costoInternacional;
    }

    // POLIMORFISMO - Implementación específica del tipo de plan
    @Override
    public String getTipoPlan() {
        return "Plan PostPago Solo Minutos";
    }

    // POLIMORFISMO - Implementación específica de los detalles
    @Override
    public String getDetallesEspecificos() {
        String detalles = "Minutos nacionales: " + minutosNacionales + "\n";
        detalles += "Costo minuto nacional: $" + costoMinutoNacional + "\n";
        detalles += "Minutos internacionales: " + minutosInternacionales + "\n";
        detalles += "Costo minuto internacional: $" + costoMinutoInternacional;
        return detalles;
    }

    // Getters y Setters
    public int getMinutosNacionales() {
        return minutosNacionales;
    }

    public void setMinutosNacionales(int minutosNacionales) {
        this.minutosNacionales = minutosNacionales;
    }

    public double getCostoMinutoNacional() {
        return costoMinutoNacional;
    }

    public void setCostoMinutoNacional(double costoMinutoNacional) {
        this.costoMinutoNacional = costoMinutoNacional;
    }

    public int getMinutosInternacionales() {
        return minutosInternacionales;
    }

    public void setMinutosInternacionales(int minutosInternacionales) {
        this.minutosInternacionales = minutosInternacionales;
    }

    public double getCostoMinutoInternacional() {
        return costoMinutoInternacional;
    }

    public void setCostoMinutoInternacional(double costoMinutoInternacional) {
        this.costoMinutoInternacional = costoMinutoInternacional;
    }
}
