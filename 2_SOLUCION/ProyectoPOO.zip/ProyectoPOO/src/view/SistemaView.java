/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import java.util.List;
import controller.*;
import model.*;

/**
 *
 * @author abrah
 */
public class SistemaView {
    private ClienteController clienteController;
    private PlanController planController;
    private FacturaController facturaController;
    
    public SistemaView() {
        this.clienteController = new ClienteController();
        this.planController = new PlanController();
        this.facturaController = new FacturaController();
    }
    
    // Menú principal
    public void mostrarMenuPrincipal() {
        System.out.println("=== SISTEMA MOV-UTPL ===");
        System.out.println("1. Gestión de Clientes");
        System.out.println("2. Gestión de Planes");
        System.out.println("3. Facturación");
        System.out.println("4. Reportes");
        System.out.println("0. Salir");
        System.out.println("Seleccione una opción:");
    }
    
    // Submenú de clientes
    public void mostrarMenuClientes() {
        System.out.println("=== GESTIÓN DE CLIENTES ===");
        System.out.println("1. Crear Cliente");
        System.out.println("2. Buscar Cliente");
        System.out.println("3. Listar Todos los Clientes");
        System.out.println("4. Actualizar Cliente");
        System.out.println("5. Eliminar Cliente");
        System.out.println("0. Volver al menú principal");
    }
    
    // Método para mostrar resultado de operación
    public void mostrarMensaje(String mensaje) {
        System.out.println(">>> " + mensaje);
    }
    
    // Método para mostrar lista de clientes
    public void mostrarListaClientes() {
        List<Cliente> clientes = clienteController.obtenerTodosLosClientes();
        if (clientes.isEmpty()) {
            System.out.println("No hay clientes registrados");
        } else {
            System.out.println("=== LISTA DE CLIENTES ===");
            for (Cliente cliente : clientes) {
                System.out.println("ID: " + cliente.getId() + " - " + cliente.getNombres());
                System.out.println("Cédula: " + cliente.getPasaporteCedula());
                System.out.println("Planes: " + cliente.getPlanes().size() + "/2");
                System.out.println("Pago mensual: $" + String.format("%.2f", cliente.calcularPagoMensual()));
                System.out.println("------------------------");
            }
        }
    }
}

