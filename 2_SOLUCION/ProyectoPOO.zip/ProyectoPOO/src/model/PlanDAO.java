/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.sql.*;
import java.util.*;
/**
 *
 * @author abrah
 */


// PlanDAO.java - Operaciones CRUD para Planes
public class PlanDAO {
    
    // CREATE - Insertar plan
    public boolean insertarPlan(PlanMovil plan) {
        String sql = """
            INSERT INTO planes (tipo_plan, nombre, descripcion, activo, minutos, costo_minutos,
                               minutos_nacionales, costo_minuto_nacional, minutos_internacionales,
                               costo_minuto_internacional, megas_gigas, costo_por_giga, 
                               tarifa_base, porcentaje_descuento) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """;
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setString(1, plan.getClass().getSimpleName());
            pstmt.setString(2, plan.getNombre());
            pstmt.setString(3, plan.getDescripcion());
            pstmt.setBoolean(4, plan.isActivo());
            
            // Inicializar todos los campos como null
            for (int i = 5; i <= 14; i++) {
                pstmt.setNull(i, Types.REAL);
            }
            
            // Establecer valores específicos según el tipo de plan
            if (plan instanceof PlanPostPagoMinutosEconomico) {
                PlanPostPagoMinutosEconomico p = (PlanPostPagoMinutosEconomico) plan;
                pstmt.setInt(5, p.getMinutos());
                pstmt.setDouble(6, p.getCostoMinutos());
                pstmt.setDouble(11, p.getMegasGigas());
                pstmt.setDouble(12, p.getCostoPorGiga());
                pstmt.setDouble(14, p.getPorcentajeDescuento());
            } else if (plan instanceof PlanPostPagoMinutos) {
                PlanPostPagoMinutos p = (PlanPostPagoMinutos) plan;
                pstmt.setInt(7, p.getMinutosNacionales());
                pstmt.setDouble(8, p.getCostoMinutoNacional());
                pstmt.setInt(9, p.getMinutosInternacionales());
                pstmt.setDouble(10, p.getCostoMinutoInternacional());
            } else if (plan instanceof PlanPostPagoMegas) {
                PlanPostPagoMegas p = (PlanPostPagoMegas) plan;
                pstmt.setDouble(11, p.getMegasGigas());
                pstmt.setDouble(12, p.getCostoPorGiga());
                pstmt.setDouble(13, p.getTarifaBase());
            } else if (plan instanceof PlanPostPagoMinutosMegas) {
                PlanPostPagoMinutosMegas p = (PlanPostPagoMinutosMegas) plan;
                pstmt.setInt(5, p.getMinutos());
                pstmt.setDouble(6, p.getCostoMinutos());
                pstmt.setDouble(11, p.getMegasGigas());
                pstmt.setDouble(12, p.getCostoPorGiga());
            }
            
            int filasAfectadas = pstmt.executeUpdate();
            
            if (filasAfectadas > 0) {
                ResultSet generatedKeys = pstmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    plan.setId(generatedKeys.getInt(1));
                }
                return true;
            }
            return false;
            
        } catch (SQLException e) {
            System.out.println("Error al insertar plan: " + e.getMessage());
            return false;
        }
    }
    
    // READ - Obtener todos los planes
    public List<PlanMovil> obtenerTodosLosPlanes() {
        List<PlanMovil> planes = new ArrayList<>();
        String sql = "SELECT * FROM planes WHERE activo = 1 ORDER BY nombre";
        
        try (Connection conn = DatabaseManager.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                PlanMovil plan = crearPlanDesdeBD(rs);
                if (plan != null) {
                    planes.add(plan);
                }
            }
            
        } catch (SQLException e) {
            System.out.println("Error al obtener planes: " + e.getMessage());
        }
        return planes;
    }
    
    // Método para asignar plan a cliente
    public boolean asignarPlanACliente(int clienteId, int planId) {
        // Verificar que el cliente no tenga más de 2 planes
        if (contarPlanesDelCliente(clienteId) >= 2) {
            System.out.println("Error: El cliente ya tiene el máximo de 2 planes");
            return false;
        }
        
        String sql = "INSERT INTO cliente_planes (cliente_id, plan_id) VALUES (?, ?)";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, clienteId);
            pstmt.setInt(2, planId);
            
            return pstmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.out.println("Error al asignar plan a cliente: " + e.getMessage());
            return false;
        }
    }
    
    // Método auxiliar para contar planes del cliente
    private int contarPlanesDelCliente(int clienteId) {
        String sql = "SELECT COUNT(*) FROM cliente_planes WHERE cliente_id = ? AND activo = 1";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, clienteId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1);
            }
            
        } catch (SQLException e) {
            System.out.println("Error al contar planes del cliente: " + e.getMessage());
        }
        return 0;
    }
    
    // Método auxiliar para crear plan desde ResultSet (igual que en ClienteDAO)
    private PlanMovil crearPlanDesdeBD(ResultSet rs) throws SQLException {
        String tipoPlan = rs.getString("tipo_plan");
        PlanMovil plan = null;
        
        switch (tipoPlan) {
            case "PlanPostPagoMinutosEconomico":
                plan = new PlanPostPagoMinutosEconomico();
                ((PlanPostPagoMinutosEconomico) plan).setMinutos(rs.getInt("minutos"));
                ((PlanPostPagoMinutosEconomico) plan).setCostoMinutos(rs.getDouble("costo_minutos"));
                ((PlanPostPagoMinutosEconomico) plan).setMegasGigas(rs.getDouble("megas_gigas"));
                ((PlanPostPagoMinutosEconomico) plan).setCostoPorGiga(rs.getDouble("costo_por_giga"));
                ((PlanPostPagoMinutosEconomico) plan).setPorcentajeDescuento(rs.getDouble("porcentaje_descuento"));
                break;
                
            case "PlanPostPagoMinutos":
                plan = new PlanPostPagoMinutos();
                ((PlanPostPagoMinutos) plan).setMinutosNacionales(rs.getInt("minutos_nacionales"));
                ((PlanPostPagoMinutos) plan).setCostoMinutoNacional(rs.getDouble("costo_minuto_nacional"));
                ((PlanPostPagoMinutos) plan).setMinutosInternacionales(rs.getInt("minutos_internacionales"));
                ((PlanPostPagoMinutos) plan).setCostoMinutoInternacional(rs.getDouble("costo_minuto_internacional"));
                break;
                
            case "PlanPostPagoMegas":
                plan = new PlanPostPagoMegas();
                ((PlanPostPagoMegas) plan).setMegasGigas(rs.getDouble("megas_gigas"));
                ((PlanPostPagoMegas) plan).setCostoPorGiga(rs.getDouble("costo_por_giga"));
                ((PlanPostPagoMegas) plan).setTarifaBase(rs.getDouble("tarifa_base"));
                break;
                
            case "PlanPostPagoMinutosMegas":
                plan = new PlanPostPagoMinutosMegas();
                ((PlanPostPagoMinutosMegas) plan).setMinutos(rs.getInt("minutos"));
                ((PlanPostPagoMinutosMegas) plan).setCostoMinutos(rs.getDouble("costo_minutos"));
                ((PlanPostPagoMinutosMegas) plan).setMegasGigas(rs.getDouble("megas_gigas"));
                ((PlanPostPagoMinutosMegas) plan).setCostoPorGiga(rs.getDouble("costo_por_giga"));
                break;
        }
        
        if (plan != null) {
            plan.setId(rs.getInt("id"));
            plan.setNombre(rs.getString("nombre"));
            plan.setDescripcion(rs.getString("descripcion"));
            plan.setActivo(rs.getBoolean("activo"));
        }
        
        return plan;
    }
}

