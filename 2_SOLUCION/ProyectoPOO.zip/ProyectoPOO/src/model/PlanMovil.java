/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author abrah
 */
public abstract class PlanMovil {

    protected int id;
    protected String nombre;
    protected String descripcion;
    protected boolean activo;

    // Constructor vacío
    public PlanMovil() {
        this.activo = true;
    }

    // Constructor con parámetros
    public PlanMovil(String nombre, String descripcion) {
        this();
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    // Métodos ABSTRACTOS - Las clases hijas DEBEN implementarlos (POLIMORFISMO)
    public abstract double calcularCosto();

    public abstract String getTipoPlan();

    public abstract String getDetallesEspecificos();

    // Método concreto que pueden usar todas las clases hijas
    public String generarResumenPlan() {
        String resumen = "=== RESUMEN DEL PLAN ===\n";
        resumen += "ID: " + id + "\n";
        resumen += "Nombre: " + nombre + "\n";
        resumen += "Tipo: " + getTipoPlan() + "\n";
        resumen += "Descripción: " + descripcion + "\n";
        resumen += getDetallesEspecificos() + "\n";
        resumen += "Costo mensual: $" + String.format("%.2f", calcularCosto()) + "\n";
        resumen += "Estado: " + (activo ? "Activo" : "Inactivo") + "\n";
        return resumen;
    }

    // Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }
}
