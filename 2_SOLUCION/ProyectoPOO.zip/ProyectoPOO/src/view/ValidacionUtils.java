/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

/**
 *
 * @author L E N O V O
 */
// ValidacionUtils.java - Utilidades de validación
public class ValidacionUtils{
    
    // Validar cédula ecuatoriana (simplificado)
    public static boolean validarCedula(String cedula) {
        if (cedula == null || cedula.length() != 10) {
            return false;
        }
        
        // Verificar que todos los caracteres sean dígitos
        for (char c : cedula.toCharArray()) {
            if (!Character.isDigit(c)) {
                return false;
            }
        }
        
        return true;
    }
    
    // Validar número de celular
    public static boolean validarNumeroCelular(String numero) {
        if (numero == null || numero.length() != 10) {
            return false;
        }
        
        // Debe empezar con 09
        if (!numero.startsWith("09")) {
            return false;
        }
        
        // Verificar que todos los caracteres sean dígitos
        for (char c : numero.toCharArray()) {
            if (!Character.isDigit(c)) {
                return false;
            }
        }
        
        return true;
    }
    
    // Validar email básico
    public static boolean validarEmail(String email) {
        if (email == null || email.isEmpty()) {
            return false;
        }
        
        return email.contains("@") && email.contains(".");
    }
    
    // Validar que los valores numéricos sean positivos
    public static boolean validarValorPositivo(double valor) {
        return valor > 0;
    }
}
