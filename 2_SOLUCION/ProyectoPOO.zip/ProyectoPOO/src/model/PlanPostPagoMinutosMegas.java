   /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author abrah
 */
public class PlanPostPagoMinutosMegas extends PlanMovil {

    private int minutos;
    private double costoMinutos;
    private double megasGigas;
    private double costoPorGiga;

    // Constructor vacío
    public PlanPostPagoMinutosMegas() {
        super();
    }

    // Constructor con parámetros
    public PlanPostPagoMinutosMegas(String nombre, String descripcion, int minutos,
            double costoMinutos, double megasGigas, double costoPorGiga) {
        super(nombre, descripcion);
        this.minutos = minutos;
        this.costoMinutos = costoMinutos;
        this.megasGigas = megasGigas;
        this.costoPorGiga = costoPorGiga;
    }

    // POLIMORFISMO - Implementación específica del cálculo de costo
    @Override
    public double calcularCosto() {
        return (minutos * costoMinutos) + (megasGigas * costoPorGiga);
    }

    // POLIMORFISMO - Implementación específica del tipo de plan
    @Override
    public String getTipoPlan() {
        return "Plan PostPago Minutos+Megas";
    }

    // POLIMORFISMO - Implementación específica de los detalles
    @Override
    public String getDetallesEspecificos() {
        String detalles = "Minutos incluidos: " + minutos + "\n";
        detalles += "Costo por minuto: $" + costoMinutos + "\n";
        detalles += "Gigas incluidos: " + megasGigas + " GB\n";
        detalles += "Costo por GB: $" + costoPorGiga;
        return detalles;
    }

    // Getters y Setters
    public int getMinutos() {
        return minutos;
    }

    public void setMinutos(int minutos) {
        this.minutos = minutos;
    }

    public double getCostoMinutos() {
        return costoMinutos;
    }

    public void setCostoMinutos(double costoMinutos) {
        this.costoMinutos = costoMinutos;
    }

    public double getMegasGigas() {
        return megasGigas;
    }

    public void setMegasGigas(double megasGigas) {
        this.megasGigas = megasGigas;
    }

    public double getCostoPorGiga() {
        return costoPorGiga;
    }

    public void setCostoPorGiga(double costoPorGiga) {
        this.costoPorGiga = costoPorGiga;
    }
}
