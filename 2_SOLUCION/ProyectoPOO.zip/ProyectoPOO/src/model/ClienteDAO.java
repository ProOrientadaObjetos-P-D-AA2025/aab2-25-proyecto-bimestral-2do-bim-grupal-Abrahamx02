/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.sql.*;
import java.util.*;

/**
 *
 * @author abrah
 */
public class ClienteDAO {
    
    // CREATE - Insertar cliente
    public boolean insertarCliente(Cliente cliente) {
        String sql = """
            INSERT INTO clientes (nombres, pasaporte_cedula, ciudad, marca_celular, 
                                modelo_celular, numero_celular, email, carrera) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """;
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setString(1, cliente.getNombres());
            pstmt.setString(2, cliente.getPasaporteCedula());
            pstmt.setString(3, cliente.getCiudad());
            pstmt.setString(4, cliente.getMarcaCelular());
            pstmt.setString(5, cliente.getModeloCelular());
            pstmt.setString(6, cliente.getNumeroCelular());
            pstmt.setString(7, cliente.getEmail());
            pstmt.setString(8, cliente.getCarrera());
            
            int filasAfectadas = pstmt.executeUpdate();
            
            if (filasAfectadas > 0) {
                ResultSet generatedKeys = pstmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    cliente.setId(generatedKeys.getInt(1));
                }
                return true;
            }
            return false;
            
        } catch (SQLException e) {
            System.out.println("Error al insertar cliente: " + e.getMessage());
            return false;
        }
    }
    
    // READ - Buscar cliente por ID
    public Cliente buscarClientePorId(int id) {
        String sql = "SELECT * FROM clientes WHERE id = ?";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                Cliente cliente = new Cliente();
                cliente.setId(rs.getInt("id"));
                cliente.setNombres(rs.getString("nombres"));
                cliente.setPasaporteCedula(rs.getString("pasaporte_cedula"));
                cliente.setCiudad(rs.getString("ciudad"));
                cliente.setMarcaCelular(rs.getString("marca_celular"));
                cliente.setModeloCelular(rs.getString("modelo_celular"));
                cliente.setNumeroCelular(rs.getString("numero_celular"));
                cliente.setEmail(rs.getString("email"));
                cliente.setCarrera(rs.getString("carrera"));
                
                // Cargar los planes del cliente
                cliente.setPlanes(cargarPlanesDelCliente(id));
                
                return cliente;
            }
            
        } catch (SQLException e) {
            System.out.println("Error al buscar cliente: " + e.getMessage());
        }
        return null;
    }
    
    // READ - Obtener todos los clientes
    public List<Cliente> obtenerTodosLosClientes() {
        List<Cliente> clientes = new ArrayList<>();
        String sql = "SELECT * FROM clientes ORDER BY nombres";
        
        try (Connection conn = DatabaseManager.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Cliente cliente = new Cliente();
                cliente.setId(rs.getInt("id"));
                cliente.setNombres(rs.getString("nombres"));
                cliente.setPasaporteCedula(rs.getString("pasaporte_cedula"));
                cliente.setCiudad(rs.getString("ciudad"));
                cliente.setMarcaCelular(rs.getString("marca_celular"));
                cliente.setModeloCelular(rs.getString("modelo_celular"));
                cliente.setNumeroCelular(rs.getString("numero_celular"));
                cliente.setEmail(rs.getString("email"));
                cliente.setCarrera(rs.getString("carrera"));
                
                // Cargar los planes de cada cliente
                cliente.setPlanes(cargarPlanesDelCliente(cliente.getId()));
                
                clientes.add(cliente);
            }
            
        } catch (SQLException e) {
            System.out.println("Error al obtener clientes: " + e.getMessage());
        }
        return clientes;
    }
    
    // UPDATE - Actualizar cliente
    public boolean actualizarCliente(Cliente cliente) {
        String sql = """
            UPDATE clientes SET nombres = ?, ciudad = ?, marca_celular = ?, 
                              modelo_celular = ?, numero_celular = ?, email = ?, carrera = ?
            WHERE id = ?
        """;
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, cliente.getNombres());
            pstmt.setString(2, cliente.getCiudad());
            pstmt.setString(3, cliente.getMarcaCelular());
            pstmt.setString(4, cliente.getModeloCelular());
            pstmt.setString(5, cliente.getNumeroCelular());
            pstmt.setString(6, cliente.getEmail());
            pstmt.setString(7, cliente.getCarrera());
            pstmt.setInt(8, cliente.getId());
            
            return pstmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.out.println("Error al actualizar cliente: " + e.getMessage());
            return false;
        }
    }
    
    // DELETE - Eliminar cliente
    public boolean eliminarCliente(int id) {
        String sql = "DELETE FROM clientes WHERE id = ?";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            return pstmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.out.println("Error al eliminar cliente: " + e.getMessage());
            return false;
        }
    }
    
    // Método auxiliar para cargar planes del cliente
    private List<PlanMovil> cargarPlanesDelCliente(int clienteId) {
        List<PlanMovil> planes = new ArrayList<>();
        String sql = """
            SELECT p.* FROM planes p 
            INNER JOIN cliente_planes cp ON p.id = cp.plan_id 
            WHERE cp.cliente_id = ? AND cp.activo = 1
        """;
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, clienteId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                PlanMovil plan = crearPlanDesdeBD(rs);
                if (plan != null) {
                    planes.add(plan);
                }
            }
            
        } catch (SQLException e) {
            System.out.println("Error al cargar planes del cliente: " + e.getMessage());
        }
        
        return planes;
    }
    
    // Método auxiliar para crear plan desde ResultSet
    private PlanMovil crearPlanDesdeBD(ResultSet rs) throws SQLException {
        String tipoPlan = rs.getString("tipo_plan");
        PlanMovil plan = null;
        
        switch (tipoPlan) {
            case "PlanPostPagoMinutosEconomico":
                plan = new PlanPostPagoMinutosEconomico();
                ((PlanPostPagoMinutosEconomico) plan).setMinutos(rs.getInt("minutos"));
                ((PlanPostPagoMinutosEconomico) plan).setCostoMinutos(rs.getDouble("costo_minutos"));
                ((PlanPostPagoMinutosEconomico) plan).setMegasGigas(rs.getDouble("megas_gigas"));
                ((PlanPostPagoMinutosEconomico) plan).setCostoPorGiga(rs.getDouble("costo_por_giga"));
                ((PlanPostPagoMinutosEconomico) plan).setPorcentajeDescuento(rs.getDouble("porcentaje_descuento"));
                break;
                
            case "PlanPostPagoMinutos":
                plan = new PlanPostPagoMinutos();
                ((PlanPostPagoMinutos) plan).setMinutosNacionales(rs.getInt("minutos_nacionales"));
                ((PlanPostPagoMinutos) plan).setCostoMinutoNacional(rs.getDouble("costo_minuto_nacional"));
                ((PlanPostPagoMinutos) plan).setMinutosInternacionales(rs.getInt("minutos_internacionales"));
                ((PlanPostPagoMinutos) plan).setCostoMinutoInternacional(rs.getDouble("costo_minuto_internacional"));
                break;
                
            case "PlanPostPagoMegas":
                plan = new PlanPostPagoMegas();
                ((PlanPostPagoMegas) plan).setMegasGigas(rs.getDouble("megas_gigas"));
                ((PlanPostPagoMegas) plan).setCostoPorGiga(rs.getDouble("costo_por_giga"));
                ((PlanPostPagoMegas) plan).setTarifaBase(rs.getDouble("tarifa_base"));
                break;
                
            case "PlanPostPagoMinutosMegas":
                plan = new PlanPostPagoMinutosMegas();
                ((PlanPostPagoMinutosMegas) plan).setMinutos(rs.getInt("minutos"));
                ((PlanPostPagoMinutosMegas) plan).setCostoMinutos(rs.getDouble("costo_minutos"));
                ((PlanPostPagoMinutosMegas) plan).setMegasGigas(rs.getDouble("megas_gigas"));
                ((PlanPostPagoMinutosMegas) plan).setCostoPorGiga(rs.getDouble("costo_por_giga"));
                break;
        }
        
        if (plan != null) {
            plan.setId(rs.getInt("id"));
            plan.setNombre(rs.getString("nombre"));
            plan.setDescripcion(rs.getString("descripcion"));
            plan.setActivo(rs.getBoolean("activo"));
        }
        
        return plan;
    }
}
