/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import model.*;

/**
 *
 * @author abrah
 */
public class TestSistema {
    
    public static void ejecutarPruebas() {
        System.out.println("=== EJECUTANDO PRUEBAS DEL SISTEMA ===\n");
        
        // Test 1: Prueba de herencia y polimorfismo
        testPolimorfismo();
        
        // Test 2: Prueba de validación de máximo 2 planes
        testValidacionMaxPlanes();
        
        // Test 3: Prueba de cálculo de costos
        testCalculoCostos();
        
        System.out.println("=== PRUEBAS COMPLETADAS ===\n");
    }
    
    // Test de polimorfismo
    private static void testPolimorfismo() {
        System.out.println("Test 1: Polimorfismo en planes");
        
        // Crear diferentes tipos de planes
        PlanMovil[] planes = {
            new PlanPostPagoMinutosEconomico("Plan Test 1", "Descripción", 100, 0.05, 2.0, 1.5, 10.0),
            new PlanPostPagoMinutos("Plan Test 2", "Descripción", 200, 0.03, 50, 0.20),
            new PlanPostPagoMegas("Plan Test 3", "Descripción", 5.0, 2.0, 3.0),
            new PlanPostPagoMinutosMegas("Plan Test 4", "Descripción", 150, 0.04, 3.0, 1.8)
        };
        
        // Demostrar polimorfismo
        for (PlanMovil plan : planes) {
            System.out.println("- Tipo: " + plan.getTipoPlan() + 
                             " | Costo: $" + String.format("%.2f", plan.calcularCosto()));
        }
        
        System.out.println("✓ Test de polimorfismo EXITOSO\n");
    }
    
    // Test de validación de máximo 2 planes
    private static void testValidacionMaxPlanes() {
        System.out.println("Test 2: Validación máximo 2 planes por cliente");
        
        Cliente cliente = new Cliente("Test User", "9999999999", "Test City", 
                                    "Test Brand", "Test Model", "0999999999", 
                                    "test@test.com", "Test Career");
        
        PlanMovil plan1 = new PlanPostPagoMegas("Plan 1", "Test", 1.0, 1.0, 1.0);
        PlanMovil plan2 = new PlanPostPagoMegas("Plan 2", "Test", 1.0, 1.0, 1.0);
        PlanMovil plan3 = new PlanPostPagoMegas("Plan 3", "Test", 1.0, 1.0, 1.0);
        
        plan1.setId(1);
        plan2.setId(2);
        plan3.setId(3);
        
        boolean result1 = cliente.agregarPlan(plan1); // Debe ser true
        boolean result2 = cliente.agregarPlan(plan2); // Debe ser true
        boolean result3 = cliente.agregarPlan(plan3); // Debe ser false
        
        if (result1 && result2 && !result3) {
            System.out.println("✓ Test de validación máximo planes EXITOSO");
            System.out.println("  - Primer plan agregado: " + result1);
            System.out.println("  - Segundo plan agregado: " + result2);
            System.out.println("  - Tercer plan rechazado: " + !result3);
        } else {
            System.out.println("✗ Test de validación FALLIDO");
        }
        System.out.println();
    }
    
    // Test de cálculo de costos
    private static void testCalculoCostos() {
        System.out.println("Test 3: Cálculo de costos");
        
        // Test plan económico con descuento
        PlanPostPagoMinutosEconomico planEconomico = new PlanPostPagoMinutosEconomico(
            "Plan Económico Test", "Test", 100, 0.10, 2.0, 2.0, 20.0
        );
        
        // Cálculo esperado: (100 * 0.10) + (2.0 * 2.0) = 14.0
        // Con 20% descuento: 14.0 - (14.0 * 0.20) = 11.2
        double costoEsperado = 11.2;
        double costoCalculado = planEconomico.calcularCosto();
        
        if (Math.abs(costoCalculado - costoEsperado) < 0.01) {
            System.out.println("✓ Test de cálculo de costos EXITOSO");
            System.out.println("  - Costo esperado: $" + String.format("%.2f", costoEsperado));
            System.out.println("  - Costo calculado: $" + String.format("%.2f", costoCalculado));
        } else {
            System.out.println("✗ Test de cálculo de costos FALLIDO");
            System.out.println("  - Esperado: $" + costoEsperado + ", Obtenido: $" + costoCalculado);
        }
        System.out.println();
    }
    
    // Método para ejecutar todas las pruebas
    public static void main(String[] args) {
        ejecutarPruebas();
    }
}

