/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.*;

/**
 *
 * @author abrah
 */
public class Cliente {

    private int id;
    private String nombres;
    private String pasaporteCedula;
    private String ciudad;
    private String marcaCelular;
    private String modeloCelular;
    private String numeroCelular;
    private String email; // Atributo adicional 1
    private String carrera; // Atributo adicional 2
    private List<PlanMovil> planes;

    // Constructor vacío
    public Cliente() {
        this.planes = new ArrayList<>();
    }

    // Constructor con parámetros
    public Cliente(String nombres, String pasaporteCedula, String ciudad,
            String marcaCelular, String modeloCelular, String numeroCelular,
            String email, String carrera) {
        this();
        this.nombres = nombres;
        this.pasaporteCedula = pasaporteCedula;
        this.ciudad = ciudad;
        this.marcaCelular = marcaCelular;
        this.modeloCelular = modeloCelular;
        this.numeroCelular = numeroCelular;
        this.email = email;
        this.carrera = carrera;
    }

    // Método para agregar un plan (máximo 2)
    public boolean agregarPlan(PlanMovil plan) {
        if (planes.size() < 2) {
            return planes.add(plan);
        }
        System.out.println("Error: Un cliente no puede tener más de 2 planes");
        return false;
    }

    // Método para remover un plan
    public boolean removerPlan(int planId) {
        for (int i = 0; i < planes.size(); i++) {
            if (planes.get(i).getId() == planId) {
                planes.remove(i);
                return true;
            }
        }
        return false;
    }

    // Método que usa POLIMORFISMO para calcular el pago total
    public double calcularPagoMensual() {
        double total = 0;
        for (PlanMovil plan : planes) {
            total += plan.calcularCosto(); // Aquí se aplica polimorfismo
        }
        return total;
    }

    // Método para mostrar información del cliente
    public String mostrarInformacion() {
        String info = "=== INFORMACIÓN DEL CLIENTE ===\n";
        info += "ID: " + id + "\n";
        info += "Nombres: " + nombres + "\n";
        info += "Cédula/Pasaporte: " + pasaporteCedula + "\n";
        info += "Ciudad: " + ciudad + "\n";
        info += "Celular: " + marcaCelular + " " + modeloCelular + "\n";
        info += "Número: " + numeroCelular + "\n";
        info += "Email: " + email + "\n";
        info += "Carrera: " + carrera + "\n";
        info += "Planes contratados: " + planes.size() + "/2\n";
        info += "Pago mensual total: $" + String.format("%.2f", calcularPagoMensual()) + "\n";
        return info;
    }

    // Getters y Setters básicos
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getPasaporteCedula() {
        return pasaporteCedula;
    }

    public void setPasaporteCedula(String pasaporteCedula) {
        this.pasaporteCedula = pasaporteCedula;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getMarcaCelular() {
        return marcaCelular;
    }

    public void setMarcaCelular(String marcaCelular) {
        this.marcaCelular = marcaCelular;
    }

    public String getModeloCelular() {
        return modeloCelular;
    }

    public void setModeloCelular(String modeloCelular) {
        this.modeloCelular = modeloCelular;
    }

    public String getNumeroCelular() {
        return numeroCelular;
    }

    public void setNumeroCelular(String numeroCelular) {
        this.numeroCelular = numeroCelular;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public List<PlanMovil> getPlanes() {
        return planes;
    }

    public void setPlanes(List<PlanMovil> planes) {
        this.planes = planes;
    }
}
