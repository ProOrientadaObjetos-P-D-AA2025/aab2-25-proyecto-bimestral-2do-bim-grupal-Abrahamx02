/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import model.*;
import controller.*;
import java.util.List;
/**
 *
 * @author abrah
 */
public class ReporteUtils {
    
    // Generar reporte de clientes
    public static String generarReporteClientes(List<Cliente> clientes) {
        StringBuilder reporte = new StringBuilder();
        reporte.append("=== REPORTE DE CLIENTES ===\n");
        reporte.append("Total de clientes: ").append(clientes.size()).append("\n\n");
        
        double totalIngresos = 0;
        int totalPlanes = 0;
        
        for (Cliente cliente : clientes) {
            reporte.append("Cliente: ").append(cliente.getNombres()).append("\n");
            reporte.append("Cédula: ").append(cliente.getPasaporteCedula()).append("\n");
            reporte.append("Ciudad: ").append(cliente.getCiudad()).append("\n");
            reporte.append("Carrera: ").append(cliente.getCarrera()).append("\n");
            reporte.append("Planes contratados: ").append(cliente.getPlanes().size()).append("\n");
            reporte.append("Pago mensual: $").append(String.format("%.2f", cliente.calcularPagoMensual())).append("\n");
            reporte.append("------------------------\n");
            
            totalIngresos += cliente.calcularPagoMensual();
            totalPlanes += cliente.getPlanes().size();
        }
        
        reporte.append("\n=== RESUMEN ===\n");
        reporte.append("Total ingresos mensuales: $").append(String.format("%.2f", totalIngresos)).append("\n");
        reporte.append("Total planes contratados: ").append(totalPlanes).append("\n");
        reporte.append("Promedio de planes por cliente: ").append(String.format("%.1f", (double)totalPlanes/clientes.size())).append("\n");
        reporte.append("Ingreso promedio por cliente: $").append(String.format("%.2f", totalIngresos/clientes.size())).append("\n");
        
        return reporte.toString();
    }
    
    // Generar reporte de planes
    public static String generarReportePlanes(List<PlanMovil> planes) {
        StringBuilder reporte = new StringBuilder();
        reporte.append("=== REPORTE DE PLANES ===\n");
        reporte.append("Total de planes disponibles: ").append(planes.size()).append("\n\n");
        
        double costoPromedio = 0;
        int contadorPorTipo[] = new int[4]; // 4 tipos de planes
        
        for (PlanMovil plan : planes) {
            reporte.append("Plan: ").append(plan.getNombre()).append("\n");
            reporte.append("Tipo: ").append(plan.getTipoPlan()).append("\n");
            reporte.append("Costo: $").append(String.format("%.2f", plan.calcularCosto())).append("\n");
            reporte.append("Estado: ").append(plan.isActivo() ? "Activo" : "Inactivo").append("\n");
            reporte.append("------------------------\n");
            
            costoPromedio += plan.calcularCosto();
            
            // Contar por tipo
            if (plan instanceof PlanPostPagoMinutosEconomico) {
                contadorPorTipo[0]++;
            } else if (plan instanceof PlanPostPagoMinutos) {
                contadorPorTipo[1]++;
            } else if (plan instanceof PlanPostPagoMegas) {
                contadorPorTipo[2]++;
            } else if (plan instanceof PlanPostPagoMinutosMegas) {
                contadorPorTipo[3]++;
            }
        }
        
        reporte.append("\n=== ESTADÍSTICAS ===\n");
        reporte.append("Costo promedio: $").append(String.format("%.2f", costoPromedio/planes.size())).append("\n");
        reporte.append("Planes Económicos: ").append(contadorPorTipo[0]).append("\n");
        reporte.append("Planes Solo Minutos: ").append(contadorPorTipo[1]).append("\n");
        reporte.append("Planes Solo Megas: ").append(contadorPorTipo[2]).append("\n");
        reporte.append("Planes Minutos+Megas: ").append(contadorPorTipo[3]).append("\n");
        
        return reporte.toString();
    }
}



