/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import model.*;
import java.util.List;

/**
 *
 * @author abrah
 */
public class PlanController {
    private PlanDAO planDAO;
    
    public PlanController() {
        this.planDAO = new PlanDAO();
    }
    
    // Crear plan económico
    public boolean crearPlanEconomico(String nombre, String descripcion, int minutos, 
                                     double costoMinutos, double gigas, double costoGiga, 
                                     double descuento) {
        PlanMovil plan = new PlanPostPagoMinutosEconomico(nombre, descripcion, minutos, 
                                                         costoMinutos, gigas, costoGiga, descuento);
        return planDAO.insertarPlan(plan);
    }
    
    // Crear plan solo minutos
    public boolean crearPlanMinutos(String nombre, String descripcion, int minutosNac, 
                                   double costoNac, int minutosInt, double costoInt) {
        PlanMovil plan = new PlanPostPagoMinutos(nombre, descripcion, minutosNac, 
                                               costoNac, minutosInt, costoInt);
        return planDAO.insertarPlan(plan);
    }
    
    // Crear plan solo megas
    public boolean crearPlanMegas(String nombre, String descripcion, double gigas, 
                                 double costoGiga, double tarifaBase) {
        PlanMovil plan = new PlanPostPagoMegas(nombre, descripcion, gigas, costoGiga, tarifaBase);
        return planDAO.insertarPlan(plan);
    }
    
    // Crear plan minutos + megas
    public boolean crearPlanMinutosMegas(String nombre, String descripcion, int minutos, 
                                        double costoMinutos, double gigas, double costoGiga) {
        PlanMovil plan = new PlanPostPagoMinutosMegas(nombre, descripcion, minutos, 
                                                     costoMinutos, gigas, costoGiga);
        return planDAO.insertarPlan(plan);
    }
    
    // Obtener todos los planes
    public List<PlanMovil> obtenerTodosLosPlanes() {
        return planDAO.obtenerTodosLosPlanes();
    }
    
    // Asignar plan a cliente
    public boolean asignarPlanACliente(int clienteId, int planId) {
        return planDAO.asignarPlanACliente(clienteId, planId);
    }
    
    // Mostrar todos los planes disponibles
    public void mostrarPlanesDisponibles() {
        List<PlanMovil> planes = obtenerTodosLosPlanes();
        System.out.println("=== PLANES DISPONIBLES ===");
        for (PlanMovil plan : planes) {
            System.out.println("ID: " + plan.getId() + " - " + plan.getNombre());
            System.out.println("Tipo: " + plan.getTipoPlan());
            System.out.println("Costo: $" + String.format("%.2f", plan.calcularCosto()));
            System.out.println("------------------------");
        }
    }
}

