/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import model.*;
import java.util.List;

/**
 *
 * @author abrah
 */
public class FacturaController {
    private ClienteDAO clienteDAO;
    
    public FacturaController() {
        this.clienteDAO = new ClienteDAO();
    }
    
    // Generar factura para un cliente
    public String generarFacturaCliente(int clienteId, String periodo) {
        Cliente cliente = clienteDAO.buscarClientePorId(clienteId);
        if (cliente == null) {
            return "Error: Cliente no encontrado";
        }
        
        Factura factura = new Factura(clienteId, periodo);
        factura.setId(generarIdFactura());
        factura.calcularTotales(cliente);
        
        return factura.generarFacturaCompleta(cliente);
    }
    
    // Calcular total a pagar por todos los clientes
    public double calcularTotalIngresosMensuales() {
        List<Cliente> clientes = clienteDAO.obtenerTodosLosClientes();
        double totalIngresos = 0;
        
        for (Cliente cliente : clientes) {
            totalIngresos += cliente.calcularPagoMensual();
        }
        
        return totalIngresos;
    }
    
    // Generar ID de factura simple
    private int generarIdFactura() {
        return (int) (Math.random() * 10000) + 1;
    }
}

