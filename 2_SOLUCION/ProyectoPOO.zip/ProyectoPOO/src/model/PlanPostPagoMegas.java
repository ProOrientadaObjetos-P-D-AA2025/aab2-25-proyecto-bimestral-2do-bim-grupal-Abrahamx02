/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author abrah
 */
public class PlanPostPagoMegas extends PlanMovil {

    private double megasGigas;
    private double costoPorGiga;
    private double tarifaBase;

    // Constructor vacío
    public PlanPostPagoMegas() {
        super();
    }

    // Constructor con parámetros
    public PlanPostPagoMegas(String nombre, String descripcion, double megasGigas,
            double costoPorGiga, double tarifaBase) {
        super(nombre, descripcion);
        this.megasGigas = megasGigas;
        this.costoPorGiga = costoPorGiga;
        this.tarifaBase = tarifaBase;
    }

    // POLIMORFISMO - Implementación específica del cálculo de costo
    @Override
    public double calcularCosto() {
        return tarifaBase + (megasGigas * costoPorGiga);
    }

    // POLIMORFISMO - Implementación específica del tipo de plan
    @Override
    public String getTipoPlan() {
        return "Plan PostPago Solo Megas";
    }

    // POLIMORFISMO - Implementación específica de los detalles
    @Override
    public String getDetallesEspecificos() {
        String detalles = "Gigas incluidos: " + megasGigas + " GB\n";
        detalles += "Costo por GB: $" + costoPorGiga + "\n";
        detalles += "Tarifa base: $" + tarifaBase;
        return detalles;
    }

    // Getters y Setters
    public double getMegasGigas() {
        return megasGigas;
    }

    public void setMegasGigas(double megasGigas) {
        this.megasGigas = megasGigas;
    }

    public double getCostoPorGiga() {
        return costoPorGiga;
    }

    public void setCostoPorGiga(double costoPorGiga) {
        this.costoPorGiga = costoPorGiga;
    }

    public double getTarifaBase() {
        return tarifaBase;
    }

    public void setTarifaBase(double tarifaBase) {
        this.tarifaBase = tarifaBase;
    }
}
