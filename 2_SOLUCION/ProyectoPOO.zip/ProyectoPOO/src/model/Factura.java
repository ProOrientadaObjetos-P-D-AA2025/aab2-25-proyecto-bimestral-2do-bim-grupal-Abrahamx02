/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author abrah
 */
public class Factura {

    private int id;
    private int clienteId;
    private String periodoFacturacion;
    private double subtotal;
    private double descuentos;
    private double total;
    private String estado;

    // Constructor vacío
    public Factura() {
        this.estado = "PENDIENTE";
    }

    // Constructor con parámetros
    public Factura(int clienteId, String periodoFacturacion) {
        this();
        this.clienteId = clienteId;
        this.periodoFacturacion = periodoFacturacion;
    }

    // Método para calcular totales basado en un cliente
    public void calcularTotales(Cliente cliente) {
        this.subtotal = cliente.calcularPagoMensual();
        this.descuentos = 0; // Por ahora sin descuentos adicionales
        this.total = this.subtotal - this.descuentos;
    }

    // Método para generar el texto de la factura
    public String generarFacturaCompleta(Cliente cliente) {
        String factura = "=== FACTURA MOV-UTPL ===\n";
        factura += "Factura ID: " + id + "\n";
        factura += "Cliente: " + cliente.getNombres() + "\n";
        factura += "Cédula: " + cliente.getPasaporteCedula() + "\n";
        factura += "Período: " + periodoFacturacion + "\n";
        factura += "Estado: " + estado + "\n\n";

        factura += "=== DETALLE DE PLANES ===\n";
        for (PlanMovil plan : cliente.getPlanes()) {
            factura += plan.generarResumenPlan() + "\n";
        }

        factura += "=== TOTALES ===\n";
        factura += "Subtotal: $" + String.format("%.2f", subtotal) + "\n";
        factura += "Descuentos: $" + String.format("%.2f", descuentos) + "\n";
        factura += "TOTAL A PAGAR: $" + String.format("%.2f", total) + "\n";
        factura += "===================\n";

        return factura;
    }

    // Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getClienteId() {
        return clienteId;
    }

    public void setClienteId(int clienteId) {
        this.clienteId = clienteId;
    }

    public String getPeriodoFacturacion() {
        return periodoFacturacion;
    }

    public void setPeriodoFacturacion(String periodoFacturacion) {
        this.periodoFacturacion = periodoFacturacion;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    public double getDescuentos() {
        return descuentos;
    }

    public void setDescuentos(double descuentos) {
        this.descuentos = descuentos;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
